<template>
  <h2>{{ message }}</h2>
  <div @click="changeMessage">click ici</div>
  <click-counter :debut="4" :step="1"></click-counter>
  <click-counter :debut="12" :step="12"></click-counter>
  <click-counter :debut="16" :step="20"></click-counter>

<!--   La suite demain sur vos écrans -->

</template>

<script setup>
import {ref} from "vue";
import ClickCounter from "./ClickCounter.vue";
const message = ref('Bonjour à tous');

function changeMessage()
{
  console.log(message)
  message.value = 'Message après avoir click';
}



setTimeout(() => {
  message.value = 'Au revoir les amiches';
}, 2000)

</script>

<style>

</style>